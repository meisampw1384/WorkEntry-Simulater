from django.apps import AppConfig


class WorkEntryAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'work_entry_app'
