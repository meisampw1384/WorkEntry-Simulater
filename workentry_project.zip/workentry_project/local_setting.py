from pathlib import Path

DEBUG = True

ALLOWED_HOSTS = []


SECRET_KEY = 'django-insecure-2l5rddv3ah+!_#_eig-d0(%jh#&_zjp$#j-vrrq1fhgf-8#8=m'

BASE_DIR = Path(__file__).resolve().parent.parent
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}